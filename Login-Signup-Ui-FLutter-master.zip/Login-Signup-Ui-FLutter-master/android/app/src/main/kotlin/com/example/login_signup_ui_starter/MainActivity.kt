package com.example.login_signup_ui_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
